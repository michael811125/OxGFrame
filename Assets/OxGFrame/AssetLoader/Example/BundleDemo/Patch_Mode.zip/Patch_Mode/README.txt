BundleDemo >> For Patch <<

Builtin => Copy inside all files to StreamingAssets (don't forget change your IP in burlcfg.txt)
Patch => Upload inside entire folder to Server

don't forget uncheck offline in BundleSetup

## this is build by win platform, please run in win editor or win ##