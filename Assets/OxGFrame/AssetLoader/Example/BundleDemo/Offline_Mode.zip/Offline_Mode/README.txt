BundleDemo >> For Offline <<

Builtin => Copy inside all files to StreamingAssets (without burlcfg.txt)

don't forget checked offline in BundleSetup

## this is build by win platform, please run in win editor or win ##