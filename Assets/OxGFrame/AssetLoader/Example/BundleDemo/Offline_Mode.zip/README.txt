BundleDemo >> For Offline <<

Builtin => Copy inside all files to StreamingAssets (without burlcfg.txt)

don't forget checked offline in BundleSetup
